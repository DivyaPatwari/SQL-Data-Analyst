--Q1
CREATE Database Brands
CREATE DATABASE Products
--------------------------------

USE Brands

--Q2
create table ITEMS_Table(
Item_id int, 
item_description varchar(100), 
vendor_nos int, 
vendor_name nvarchar(100), 
bottle_size int, 
bottle_price money)


--Q3
insert into ITEMS_Table values(1,'Travis Hasse Apple Pie', 305, 'Mhw Ltd',750, 9.77)
insert into ITEMS_Table values(2,'Daristi Xtabentun', 391, 'Anchor Distilling (preiss Imports)', 750, 14.12)
insert into ITEMS_Table values(3,'Hiram Walker Peach Brandy', 370, 'Pernod Ricard Usa/austin Nichols', 1000, 6.50)
insert into ITEMS_Table values(4,'Oak Cross Whisky', 305, 'Mhw Ltd', 750, 25.33)
insert into ITEMS_Table values(5,'Uv Red(cherry) Vodka', 380, 'Phillips Beverage Company', 200, 1.97)
insert into ITEMS_Table values(6,'Heaven Hill Old Style White Label', 259, 'Heaven Hill Distilleries Inc.', 750, 6.37)
insert into ITEMS_Table values(7,'Hyde Herbal Liqueur', 194, 'Fire Tail Brands Llc', 750 , 5.06)
insert into ITEMS_Table values(8,'Dupont Calvados Fine Reserve', 403, 'Robert Kacher Selections', 750, 23.61)

UPDATE ITEMS_Table SET item_description = 'D''aristi Xtabentun' WHERE ITEM_ID = 2

SELECT * FROM ITEMS_Table

--Small Table :--
--Q1
select item_description from ITEMS_Table Where bottle_size=750

--Q2
select Vendor_name from ITEMS_Table Where vendor_nos in (305, 380, 391)

--Q3
select sum(bottle_price) from ITEMS_Table 

--Q4
Alter table ITEMS_Table ALTER COLUMN ITEM_ID INT NOT NULL ;

Alter table ITEMS_Table add primary key (Item_id);

--Alter table ITEMS_Table ADD CONSTRAINT Pk_Item_id PRIMARY KEY (item_id);

--Q5 
SELECT ITEM_ID from ITEMS_Table Where bottle_PRICE=5.06


--Advanced questions


--Q4
select * from ITEMS_Table
SELECT SUBSTRING(item_description, 1, CHARINDEX(' ', item_description) - 1) AS Firstname,     
       SUBSTRING(item_description,
                 CHARINDEX(' ', item_description) + 1,
                 LEN(item_description) - CHARINDEX(' ', item_description)) AS Lastname
FROM ITEMS_Table











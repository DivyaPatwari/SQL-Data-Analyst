--Task 1
--Q1
create database VIT_University

use VIT_University

--Q2
create table College_Table(
		College_ID int primary key,
		College_Name varchar(50),
		College_Area varchar(50)) ;

create table Department_Table(
       
		Dept_ID int primary key,
		Dept_Name varchar (50),
		Dept_Facility varchar(250),
		clg_ID INT NOT NULL);

create table Professor_Table(
		Professor_ID int primary key,
		Professor_Name varchar(50),
		Professor_Subject varchar(50));


create table Student_Table(
		
		Student_ID int primary key,
		Student_Name varchar(50),
		Student_Stream varchar(50),
		PROFF_ID INT NOT NULL);

select * from Department_Table;
select * from College_Table
select * from Professor_Table
select * from Student_Table

exec sp_rename 'Department_table.DEPT_Facility', 'Dept_Faculty', 'column';


--Q3
ALTER TABLE Department_Table add foreign key(clg_ID) references college_table(college_ID)

--Q4
ALTER TABLE Student_Table add foreign key (proff_ID) references professor_table(professor_ID)


--Q5
insert into College_Table values(1, 'PICT', 'Pune'),(2, 'PCCOE', 'Pune'), (3, 'COEP', 'Pune'), (4, 'VJTI', 'Mumbai'), (5, 'NIT', 'Nagpur'), (6, 'KIT', 'Bangalore'), (7, 'CKP', 'Chennai'), (8, 'Fite', 'Roorkie'), (9, 'SCCIO', 'Mumbai'), (10, 'DPS', 'Delhi');

insert into Department_Table values(1, 'IT', 'Dhabe', 1 ), (3, 'Comp', 'kulkarni', 1), (2, 'IT', 'Patil', 4), (7, 'ENTC', 'Pawar', 1), (8, 'ELEX', 'Singh', 2), (5, 'Industrial', 'Raje', 8), (6, 'PRODUCTION', 'Gije', 3), (9, 'Comp', 'Pawar', 4), (10, 'Mech', 'Divya', 5), (11, 'Mech', 'vj',7);


insert into Professor_Table values(1,'Dhabe', 'AI'), (2,'kulkarni', 'DSA'), (3,'Swain', 'Maths'), (4,'Bailke', 'AT'), (6,'Donge', 'DSA'), (8,'Patil', 'Angular'), (7,'Singh', 'PL/SQL'), (11,'Patil', 'MATH3'), (9,'Pawar', 'Math2'),(15,'Gije', 'Digital Electronics'), (5, 'Disha', 'ML');

insert into Student_TABLE values(1, 'Ram', 'Sci', 1), (11, 'Sham', 'Maths', 2),(4, 'Ramesh', 'Bio', 4),(5, 'Hermoine', 'Math', 2),(7, 'Ron', 'Bio', 4),(8, 'Riya', 'Bio', 4),(2, 'Divya', 'Sci',1),(3, 'Pooja', 'Commerce', 15),(6, 'Dhanno', 'Arts', 8),(21, 'Adi', 'Arts',8)



--Task 2
--Q1
select college_id, College_name from College_Table;

--Q2
SELECT TOP 5 * FROM Student_Table

--Q3
SELECT  Professor_Name FROM  Professor_Table WHERE Professor_ID= 5

--Q4
SELECT UPPER(PROFESSOR_NAME) FROM Professor_Table;

--Q5
SELECT STUDENT_NAME FROM Student_Table WHERE lower(Student_Name) LIKE 'a%'

--Q6
select College_Name from College_Table where lower(College_Name) like '%a'

--Q7
ALTER TABLE PROFESSOR_TABLE ADD SALARY MONEY ;

--Q8
ALTER TABLE student_TABLE ADD contact int ;

--Q9
UPDATE Professor_Table SET SALARY = 20000 
UPDATE Professor_Table SET SALARY = 40000 WHERE Professor_ID=2
UPDATE Professor_Table SET SALARY = 70000 WHERE Professor_ID=5

SELECT SUM(SALARY) AS TOTAL_SALARY FROM Professor_Table

--Q10
ALTER TABLE PROFESSOR_TABLE ALTER COLUMN SALARY INT;


--TASK 3

--Q1
SELECT TOP 5 * FROM Student_Table S JOIN Professor_Table P ON S.PROFF_ID = P.Professor_ID

--Q2
alter table professor_table add  dep_id int not null default 1
ALTER TABLE professor_table add foreign key (dep_id) references department_table(dept_ID)

select * from College_Tables_data
select * from Department_Table;
select * from Professor_Table
select * from Student_Table

select * from college_tables_data c, department_table d, Professor_Table p, Student_Table s 
where c.college_id= d.clg_ID 
and d.Dept_ID = p.dep_id
and p.Professor_ID = s.PROFF_ID





--Q3
SELECT * FROM Professor_Table WHERE SALARY IS NULL

select * from Department_Table where dept_faculty is null




--Q4
Create view Clg_Vw
as
select * from College_Table where lower(College_Name) like 'c%'


select * from Clg_Vw

--Q5
CREATE PROC spProfessorData
@PRO_ID INT
AS
BEGIN 
SELECT * FROM Professor_Table
WHERE Professor_ID = @PRO_ID
END

exec spProfessorData
@PRO_ID = 4

--Q6
EXEC sp_rename, 'college_table', 'College_Tables_Data'













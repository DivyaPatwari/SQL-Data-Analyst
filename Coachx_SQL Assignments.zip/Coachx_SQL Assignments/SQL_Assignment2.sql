--Assignment No 2
--Q1
create database Order_Stores_Data
use Order_Stores_Data

 --Q2
create table Orders_Table(
OrderDate date, 
Region varchar(10), 
Rep varchar(20), 
Order_Item varchar(20), 
Units int, 
UnitCost money, 
Total_Price money,
Order_Id int);

create table Stores_Table(
Store_Id int,
StoreType char, 
assortment int, 
CompetitionDistance int,
Month int,
year int, 
PromoInterval varchar(20))



--Q3 
insert into Orders_Table values('1-6-21','East','Aruna','Pencil',95, 1.99,189.05,1);
insert into Orders_Table values('1-23-21','Central','Kivell','Eraser',50, 19.99,999.50,2)
insert into Orders_Table values('2-9-21','Central','Ganesh','', 36, 4.99, 179.64,3)
insert into Orders_Table values('2-26-21','Central','Payal','',27,19.99, 539.73,4)
insert into Orders_Table values('3-15-21','West','Sorvino','',56, 2.99, 167.44,5)
insert into Orders_Table values('4-1-21','East','Hitesh','Pencil', 60, 4.99, 299.40,6)
insert into Orders_Table values('4-18-21','Central','Akshita','', 75, 1.99, 149.25,7)
insert into Orders_Table values('5-5-21','Central','Ruchika','Books',90,4.99,449.1,8)
insert into Orders_Table values('5-22-21','West','Surbhi','',32,1.99,63.68,9)
insert into Orders_Table values('6-8-21','East','Jones','Suitcase',60,8.99,539.40,10)

insert into Stores_Table values(1,'c',27,1270,9,2008,'Jan')
insert into Stores_Table values(2,'a',43,570,11,2007,'Feb')
insert into Stores_Table values(3,'a',35,14130,12,2006,'Mar')
insert into Stores_Table values(4,'c',31,620,9,2009,'')
insert into Stores_Table values(5,'a',42,29910,4,2015,'May')
insert into Stores_Table values(6,'a',27,310,12,2013,'June')
insert into Stores_Table values(7,'a',12,24000,4,2013,'')
insert into Stores_Table values(8,'a',14,7520,10,2014,'Aug')
insert into Stores_Table values(9,'a',14,2030,8,2000,'')
insert into Stores_Table values(10,'a',45,3160,9,2009,'Oct')



select * from Orders_Table
select * from Stores_Table

--Q3
alter table orders_table alter column Order_id int not null
alter table orders_table add primary key (Order_id)

--Q4

ALTER TABLE STORES_TABLE ADD  STORE_NAMES VARCHAR(20)

UPDATE Stores_Table SET STORE_NAMES = 'Car' WHERE Store_Id = 1
UPDATE Stores_Table SET STORE_NAMES = 'Bikes' WHERE Store_Id = 2
UPDATE Stores_Table SET STORE_NAMES = 'Hardware' WHERE Store_Id = 3
UPDATE Stores_Table SET STORE_NAMES = 'Electrics' WHERE Store_Id = 4
UPDATE Stores_Table SET STORE_NAMES = 'Fibers' WHERE Store_Id = 5
UPDATE Stores_Table SET STORE_NAMES = 'Elastics' WHERE Store_Id = 6
UPDATE Stores_Table SET STORE_NAMES = 'Books' WHERE Store_Id = 7
UPDATE Stores_Table SET STORE_NAMES = 'Shoes' WHERE Store_Id = 8
UPDATE Stores_Table SET STORE_NAMES = 'Clothes' WHERE Store_Id = 9
UPDATE Stores_Table SET STORE_NAMES = 'Scraps' WHERE Store_Id = 10

--Q5
ALTER TABLE Stores_table add foreign key (Store_Id) references orders_table(Order_Id)

--Q6

UPDATE Orders_Table SET Order_Item ='Compass' WHERE ORDER_ID=3
UPDATE Orders_Table SET Order_Item ='Torch' WHERE ORDER_ID=4
UPDATE Orders_Table SET Order_Item ='Phone' WHERE ORDER_ID=5
UPDATE Orders_Table SET Order_Item ='Laptop' WHERE ORDER_ID=7
UPDATE Orders_Table SET Order_Item ='Box' WHERE ORDER_ID=9

--Q7


--Q8
sp_rename 'STORES_TABLE.assortment', 'Store_Nos', 'COLUMN';


--Q9
sp_rename 'Orders_Table.ORDER_Item', 'Item_Name', 'COLUMN';
sp_rename 'Orders_Table.Rep', 'Customers_Name', 'COLUMN';


--Q10
SELECT * FROM Orders_Table ORDER BY UnitCost desc, Total_Price asc

--Q11
sp_rename 'Orders_Table.Customers_Name', 'Cus_Name', 'COLUMN';
select Region, count(Cus_name) AS Count_of_customers from orders_table group by Region

--Q12
SELECT SUM (Total_price) as Top_Price, sum (UnitCost) as unicst from Orders_Table


--Q13
SELECT o.OrderDate, o.UnitCost, s.storetype, s.year from Orders_Table o join Stores_Table s on o.Order_Id=s.Store_Id

--Q14
SELECT ORDER_ITEM, REGION FROM Orders_Table WHERE ORDER_ID IN (4,5,6,9)

--Q15
SELECT YEAR FROM Stores_Table WHERE CompetitionDistance IN (29910,310,3160)

--Q16
SELECT ORDER_ITEM FROM Orders_Table WHERE Total_Price>200 AND Total_Price<400

--Q17
sp_rename 'STORES_TABLE.CompetitionDistance', 'CD', 'COLUMN';
SELECT SUM(CD) AS TOTAL_CD FROM Stores_Table

--Q18
SELECT StoreType, sum(CD) as total_CD  from Stores_Table group by storetype

--Q19
SELECT * FROM Orders_Table CROSS JOIN Stores_Table

--Q20
DROP TABLE Stores_Table
DROP TABLE Orders_Table
DROP DATABASE Order_Stores_Data



--Basics Questions:-

--Q1
CREATE Database Brands
CREATE DATABASE Products
----------------------------------
USE PRODUCTS;

--Q2
CREATE TABLE PRODUCT_Table(Product_Id int, 
Country Varchar(50), 
Product varchar(50),  
Unit_Sold money, 
Manufacturing_Price money,
Sale_Price Money,
Gross_Sales money, 
Sales money,
COGS money, 
Profit money,
P_Date date,
Month_number int,
Month_Name varchar(20), 
PYear int);

--Q3
insert into PRODUCT_Table values(1,'Canada','Carretera',1618.5,3,20,32370,32370,16185,16185,'01-01-2014',1,'January',2014);
insert into PRODUCT_Table values(2,'Germany','Carretera',1321,3,20,26420,26420,13210,13210,'01-01-2014',1,'January',2015);
insert into PRODUCT_Table values(3,'France','Carretera',2178,3,15,32670,32670,21780,10890,'01-06-2014',6,'June',2016);
insert into PRODUCT_Table values(4,'Germany','Carretera',888,3,15,13320,13320,8880,4440,'01-06-2014',6,'June',2017);
insert into PRODUCT_Table values(5,'Mexico','Carretera',2470,3,15,37050,37050,24700,12350,'01-06-2014',6,'June',2018);
insert into PRODUCT_Table values(6,'Germany','Carretera',1513,3,350,529550,529550,393380,136170,'01-12-2014',12,'December',2019);
insert into PRODUCT_Table values(7,'Germany','Montana',921,5,15,13815,13815,9210,4605,'01-03-2014',3,'March',2020);
insert into PRODUCT_Table values(8,'Canada','Montana',2518,5,12,30216,30216,7554,22662,'01-06-2014',6,'June',2021);

select * from PRODUCT_Table;

--Q4
DELETE FROM PRODUCT_Table WHERE Unit_Sold IN (1618.5, 888, 2470)


--Q5
DROP TABLE PRODUCT_Table



--Intermediate Questions
select * from PRODUCT_Table;

--Q1
SELECT SUM(Sale_Price), sum(Gross_Sales) from product_Table

--Q2
select PYear, Sales from PRODUCT_Table where Sales =(SELECT MAX(Sales) from PRODUCT_Table)

--Q3	
SELECT * FROM PRODUCT_Table where sales = 37050.00
SELECT Product_Id, Product FROM PRODUCT_Table where sales = 37050.00

--Q4
SELECT COUNTRY, profit FROM PRODUCT_Table where profit between 4605 and  22662.00

--Q5
SELECT PRODUCT_Id from PRODUCT_Table where sales = 24700.00

--Advance Questions:--
SELECT * FROM [Products].[dbo].PRODUCT_Table 
SELECT * FROM [Brands].[dbo].ITEMS_Table 


--Q1

SELECT * FROM [Products].[dbo].PRODUCT_Table p INNER JOIN [Brands].[dbo].ITEMS_Table i ON p.PRODUCT_ID= i.ITEM_ID

SELECT * FROM [Products].[dbo].PRODUCT_Table p FULL OUTER  JOIN [Brands].[dbo].ITEMS_Table i ON p.PRODUCT_ID= i.ITEM_ID

SELECT * FROM [Products].[dbo].PRODUCT_Table p left JOIN [Brands].[dbo].ITEMS_Table i ON p.PRODUCT_ID= i.ITEM_ID


--Q2
SELECT * FROM [Products].[dbo].PRODUCT_Table p FULL OUTER  JOIN [Brands].[dbo].ITEMS_Table i ON p.PRODUCT_ID= i.ITEM_ID

SELECT i.*, p.* FROM [Products].[dbo].PRODUCT_Table p Right  JOIN [Brands].[dbo].ITEMS_Table i ON p.PRODUCT_ID= i.ITEM_ID

SELECT * FROM [Products].[dbo].PRODUCT_Table  CROSS JOIN [Brands].[dbo].ITEMS_Table 

--Q3
SELECT i.item_description, p.product  FROM [Products].[dbo].PRODUCT_Table p INNER JOIN [Brands].[dbo].ITEMS_Table i ON p.PRODUCT_ID= i.ITEM_ID where p.gross_sales= 13320.00


--Q4
select string_split(















create database std
use std

create table student(StudentId int primary key, 
S_name varchar(100),
Surname varchar(100),
Birthdate date,
Gender char,
class varchar(100),
point int)


--Assignment Answers below

select * from student

select S_name, surname, class from student

select * from student where gender = 'F'

select class from student group by class

select * from student where gender = 'F' and Class = '10Math'

select S_name, surname, class from student where class in ('10Math', '10Sci')

select S_name, surname from student

select concat(S_name, ' ',surname) as Full_name from student

select * from student where S_name like 'a%'

select * from student where S_name in ('emma', 'sophia', 'robert')

select * from student where S_name like 'a%' or S_name like 'd%' or S_name like 'k%'

select S_name, surname, class, gender from student where gender = 'M' and Class = '9Math' or gender = 'F' and Class = '9His'

select * from student where gender = 'M' and Class = '10Math' or Class = '10Bio'

select * from student where birthdate like '%1989'


